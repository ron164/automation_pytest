# -*- coding: utf-8 -*-
# @Time : 17-10-2022 20:07
# @Author : rohan
# @File : setup.py.py
from setuptools import setup


if __name__ == "__main__":
    setup()